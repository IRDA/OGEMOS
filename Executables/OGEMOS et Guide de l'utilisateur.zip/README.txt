Lancement OGEMOS
-----------------
Pour lancer OGEMOS, l'utilisateur doit d'abord
s'assurer d'avoir bien dézipper le fichier puis cliquer
sur le dossier OGEMOS puis APP_OGEMOS et lancer
l'exécutable qui s'y trouve.

Pour plus d'information sur l'utilisation d'OGEMOS,
veuillez vous référer au Guide de l'utilisateur inclut
dans le fichier zip.